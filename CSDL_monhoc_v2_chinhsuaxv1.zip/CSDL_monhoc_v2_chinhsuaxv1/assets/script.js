// Khởi tạo bản đồ, với vị trí trung tâm là Hà Nội và mức zoom = 6
var map = L.map('map').setView([21.0285, 105.8542], 6);

// Thêm layer bản đồ từ OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Dữ liệu trạm quan trắc (Dữ liệu này có thể được lấy từ cơ sở dữ liệu)
var stations = [
    {
        station_id: 'ST001',
        station_name: 'Trạm Quan Trắc Môi Trường Hà Nội',
        latitude: 21.0285,
        longitude: 105.8542,
        address: 'Đại học Khoa học Tự nhiên, Hà Nội'
    },
    {
        station_id: 'ST002',
        station_name: 'Trạm Quan Trắc Môi Trường Hồ Chí Minh',
        latitude: 10.7731,
        longitude: 106.6594,
        address: 'Đại học Bách khoa TP.HCM'
    },
    {
        station_id: 'ST003',
        station_name: 'Trạm Quan Trắc Môi Trường Đà Nẵng',
        latitude: 16.0544,
        longitude: 108.2022,
        address: 'Đại học Đà Nẵng'
    },
    {
        station_id: 'ST004',
        station_name: 'Trạm Quan Trắc Môi Trường Cần Thơ',
        latitude: 10.0301,
        longitude: 105.7845,
        address: 'Trường Đại học Cần Thơ'
    },
    {
        station_id: 'ST005',
        station_name: 'Trạm Quan Trắc Môi Trường Huế',
        latitude: 16.4625,
        longitude: 107.5960,
        address: 'Trường Đại học Huế'
    }
];

// Thêm các điểm đánh dấu cho mỗi trạm trên bản đồ
stations.forEach(function(station) {
    L.marker([station.latitude, station.longitude])
        .addTo(map)
        .bindPopup(
            "<b>" + station.station_name + "</b><br>" +
            "Station ID: " + station.station_id + "<br>" +
            "Địa chỉ: " + station.address
        );
});
