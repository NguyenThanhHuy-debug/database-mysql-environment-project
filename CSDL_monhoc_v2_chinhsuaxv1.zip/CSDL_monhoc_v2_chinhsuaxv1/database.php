<?php

class EnvironmentalDatabase {
    // private $host = 'localhost';
    // private $username = 'root';
    // private $password = '';
    // private $database = 'environmental_monitoring';
    // private $conn;


    // 'host' => 'localhost',
    // 'username' => 'wseometc_thanhhuy_csdl_v1',
    // 'password' => 'Huy27092003@',
    // 'database' => 'wseometc_thanhhuy_csdl_database_v1'
    private $host = 'localhost';
    private $username = 'root';
    private $password = 'Huy27092003@';
    private $database = 'database_csdl_v1';
    private $conn;
    // Kết nối cơ sở dữ liệu
    public function __construct() {
        try {
            $this->conn = new PDO(
                "mysql:host={$this->host};dbname={$this->database};charset=utf8mb4", 
                $this->username, 
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            die("Kết nối cơ sở dữ liệu thất bại: " . $e->getMessage());
        }
    }

    // Thêm trạm mới
    public function addStation($data) {
        $sql = "INSERT INTO stations (
            station_id, station_name, address, phone, 
            latitude, longitude, elevation, 
            installation_date, status
        ) VALUES (
            :station_id, :station_name, :address, :phone, 
            :latitude, :longitude, :elevation, 
            :installation_date, :status
        )";

        try {
            $stmt = $this->conn->prepare($sql);
            return $stmt->execute($data);
        } catch(PDOException $e) {
            error_log("Lỗi thêm trạm: " . $e->getMessage());
            return false;
        }
    }

    // Thêm bản ghi đo
    public function addMeasurement($data) {
        $sql = "INSERT INTO measurements (
            station_id, temperature, humidity, light_intensity, 
            wind_speed, wind_direction, air_pressure, 
            rainfall, pm25, pm10, co2, 
            noise_level, uv_index, battery_level
        ) VALUES (
            :station_id, :temperature, :humidity, :light_intensity, 
            :wind_speed, :wind_direction, :air_pressure, 
            :rainfall, :pm25, :pm10, :co2, 
            :noise_level, :uv_index, :battery_level
        )";

        try {
            $stmt = $this->conn->prepare($sql);
            return $stmt->execute($data);
        } catch(PDOException $e) {
            error_log("Lỗi thêm bản ghi đo: " . $e->getMessage());
            return false;
        }
    }

    // Thêm nhật ký bảo trì
    public function addMaintenanceLog($data) {
        $sql = "INSERT INTO maintenance_logs (
            station_id, maintenance_date, maintenance_type, 
            description, technician_name, next_maintenance_date
        ) VALUES (
            :station_id, :maintenance_date, :maintenance_type, 
            :description, :technician_name, :next_maintenance_date
        )";

        try {
            $stmt = $this->conn->prepare($sql);
            return $stmt->execute($data);
        } catch(PDOException $e) {
            error_log("Lỗi thêm nhật ký bảo trì: " . $e->getMessage());
            return false;
        }
    }

    // Thêm ngưỡng cảm biến
    public function addSensorThreshold($data) {
        $sql = "INSERT INTO sensor_thresholds (
            log_id, station_id, sensor_type, 
            min_temperature, max_temperature,
            min_humidity, max_humidity,
            min_wind_speed, max_wind_speed,
            min_light, max_light,
            calibration_notes, valid_from, valid_until, 
            technician_id
        ) VALUES (
            :log_id, :station_id, :sensor_type, 
            :min_temperature, :max_temperature,
            :min_humidity, :max_humidity,
            :min_wind_speed, :max_wind_speed,
            :min_light, :max_light,
            :calibration_notes, :valid_from, :valid_until, 
            :technician_id
        )";

        try {
            $stmt = $this->conn->prepare($sql);
            return $stmt->execute($data);
        } catch(PDOException $e) {
            error_log("Lỗi thêm ngưỡng cảm biến: " . $e->getMessage());
            return false;
        }
    }

    // Thêm cảnh báo
    public function addAlert($data) {
        $sql = "INSERT INTO alerts (
            station_id, alert_type, severity, 
            message, resolved
        ) VALUES (
            :station_id, :alert_type, :severity, 
            :message, :resolved
        )";

        try {
            $stmt = $this->conn->prepare($sql);
            return $stmt->execute($data);
        } catch(PDOException $e) {
            error_log("Lỗi thêm cảnh báo: " . $e->getMessage());
            return false;
        }
    }

    // Lấy dữ liệu đo mới nhất của một trạm
    public function getLatestMeasurements($station_id) {
        $sql = "SELECT * FROM measurements 
                WHERE station_id = :station_id 
                ORDER BY timestamp DESC 
                LIMIT 1";

        try {
            $stmt = $this->conn->prepare($sql);
            $stmt->execute(['station_id' => $station_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Lỗi lấy dữ liệu đo: " . $e->getMessage());
            return null;
        }
    }

    // Kiểm tra ngưỡng cảnh báo
    public function checkThresholds($station_id, $measurements) {
        $sql = "SELECT * FROM sensor_thresholds 
                WHERE station_id = :station_id 
                AND valid_from <= NOW() 
                AND (valid_until IS NULL OR valid_until > NOW())";

        try {
            $stmt = $this->conn->prepare($sql);
            $stmt->execute(['station_id' => $station_id]);
            $thresholds = $stmt->fetch(PDO::FETCH_ASSOC);

            $alerts = [];

            // Kiểm tra nhiệt độ
            if ($measurements['temperature'] < $thresholds['min_temperature'] || 
                $measurements['temperature'] > $thresholds['max_temperature']) {
                $alerts[] = [
                    'type' => 'temperature',
                    'message' => 'Nhiệt độ ngoài ngưỡng cho phép'
                ];
            }

            // Kiểm tra độ ẩm
            if ($measurements['humidity'] < $thresholds['min_humidity'] || 
                $measurements['humidity'] > $thresholds['max_humidity']) {
                $alerts[] = [
                    'type' => 'humidity',
                    'message' => 'Độ ẩm ngoài ngưỡng cho phép'
                ];
            }

            return $alerts;
        } catch(PDOException $e) {
            error_log("Lỗi kiểm tra ngưỡng: " . $e->getMessage());
            return null;
        }
    }

    // Đóng kết nối
    public function __destruct() {
        $this->conn = null;
    }


    //phướng thưc này dược thêm cho thanh search
    public function getAllStations() {
        $sql = "SELECT station_id, station_name FROM stations";
        try {
            $stmt = $this->conn->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Lỗi lấy danh sách trạm: " . $e->getMessage());
            return [];
        }
    }
}

// Ví dụ sử dụng
try {
    $db = new EnvironmentalDatabase();

    // // Thêm một trạm mới
    // $stationData = [
    //     'station_id' => 'ST001',
    //     'station_name' => 'Trạm Quan Trắc Môi Trường Hà Nội',
    //     'address' => 'Đại học Khoa học Tự nhiên, Hà Nội',
    //     'phone' => '0243123456',
    //     'latitude' => 21.0285,
    //     'longitude' => 105.8542,
    //     'elevation' => 10.5,
    //     'installation_date' => date('Y-m-d'),
    //     'status' => 'active'

      
        
    //];


    // Mảng chứa thông tin của nhiều trạm
    // $stationsData = [
    //     [
    //         'station_id' => 'ST001',
    //         'station_name' => 'Trạm Quan Trắc Môi Trường Hà Nội',
    //         'address' => 'Đại học Khoa học Tự nhiên, Hà Nội',
    //         'phone' => '0243123456',
    //         'latitude' => 21.0285,
    //         'longitude' => 105.8542,
    //         'elevation' => 10.5,
    //         'installation_date' => date('Y-m-d'),
    //         'status' => 'active'
    //     ],
    //     [
    //         'station_id' => 'ST002',
    //         'station_name' => 'Trạm Quan Trắc Môi Trường Hồ Chí Minh',
    //         'address' => 'Đại học Bách Khoa, Hồ Chí Minh',
    //         'phone' => '0283456789',
    //         'latitude' => 10.7731,
    //         'longitude' => 106.6594,
    //         'elevation' => 5.2,
    //         'installation_date' => date('Y-m-d'),
    //         'status' => 'active'
    //     ],
    //     [
    //         'station_id' => 'ST003',
    //         'station_name' => 'Trạm Quan Trắc Môi Trường Đà Nẵng',
    //         'address' => 'Đại học Đà Nẵng',
    //         'phone' => '0236789012',
    //         'latitude' => 16.0544,
    //         'longitude' => 108.2022,
    //         'elevation' => 15.3,
    //         'installation_date' => date('Y-m-d'),
    //         'status' => 'active'
    //     ]
    // ];
    // //$db->addStation($stationData);
    // foreach ($stationsData as $stationData) {
    //     $db->addStation($stationData);
    // }

    // Thêm dữ liệu cho từng trạm
    $stationData1 = [
        'station_id' => 'ST001',
        'station_name' => 'Trạm Quan Trắc Môi Trường Hà Nội',
        'address' => 'Đại học Khoa học Tự nhiên, Hà Nội',
        'phone' => '0243123456',
        'latitude' => 21.0285,
        'longitude' => 105.8542,
        'elevation' => 10.5,
        'installation_date' => date('Y-m-d'),
        'status' => 'active'
    ];

    $stationData2 = [
        'station_id' => 'ST002',
        'station_name' => 'Trạm Quan Trắc Môi Trường Hồ Chí Minh',
        'address' => 'Đại học Bách Khoa, Hồ Chí Minh',
        'phone' => '0283456789',
        'latitude' => 10.7731,
        'longitude' => 106.6594,
        'elevation' => 5.2,
        'installation_date' => date('Y-m-d'),
        'status' => 'active'
    ];

    $stationData3 = [
        'station_id' => 'ST003',
        'station_name' => 'Trạm Quan Trắc Môi Trường Đà Nẵng',
        'address' => 'Đại học Đà Nẵng',
        'phone' => '0236789012',
        'latitude' => 16.0544,
        'longitude' => 108.2022,
        'elevation' => 15.3,
        'installation_date' => date('Y-m-d'),
        'status' => 'active'
    ];

    $stationData4 = [
        'station_id' => 'ST004',
        'station_name' => 'Trạm Quan Trắc Môi Trường Cần Thơ',
        'address' => 'Đại học Cần Thơ, Cần Thơ',
        'phone' => '0292387654',
        'latitude' => 10.0301,
        'longitude' => 105.7845,
        'elevation' => 7.8,
        'installation_date' => date('Y-m-d'),
        'status' => 'active'
    ];
    
    // Thêm dữ liệu cho trạm thứ 5
    $stationData5 = [
        'station_id' => 'ST005',
        'station_name' => 'Trạm Quan Trắc Môi Trường Huế',
        'address' => 'Đại học Huế, Huế',
        'phone' => '0234123456',
        'latitude' => 16.4625,
        'longitude' => 107.5960,
        'elevation' => 8.0,
        'installation_date' => date('Y-m-d'),
        'status' => 'active'
    ];

    // Thêm từng trạm
    $db->addStation($stationData1);
    $db->addStation($stationData2);
    $db->addStation($stationData3);
    // Thêm các trạm vào cơ sở dữ liệu
    $db->addStation($stationData4);
    $db->addStation($stationData5);

    // Thêm bản ghi đo
    $measurementDataST001 = [
        'station_id' => 'ST001',
        'temperature' => 28.5,
        'humidity' => 65.2,
        'light_intensity' => 12000,
        'wind_speed' => 2.3,
        'wind_direction' => 180,
        'air_pressure' => 1013.25,
        'rainfall' => 0,
        'pm25' => 25.5,
        'pm10' => 35.2,
        'co2' => 450,
        'noise_level' => 55.3,
        'uv_index' => 6.2,
        'battery_level' => 85.5
    ];
    $db->addMeasurement($measurementDataST001);


    $measurementDataST002 = [
        'station_id' => 'ST002',
        'temperature' => 30.5,
        'humidity' => 65.0,
        'light_intensity' => 10000,
        'wind_speed' => 1.5,
        'wind_direction' => 210,
        'air_pressure' => 1013.15,
        'rainfall' => 0.2,
        'pm25' => 35.0,
        'pm10' => 45.0,
        'co2' => 500,
        'noise_level' => 60.0,
        'uv_index' => 7.0,
        'battery_level' => 90.0
    ];
    $resultST002 = $db->addMeasurement($measurementDataST002);


    // Bản ghi đo cho ST003 (Đà Nẵng - gần biển)
    $measurementDataST003 = [
        'station_id' => 'ST003',
        'temperature' => 29.0,
        'humidity' => 75.0,
        'light_intensity' => 11000,
        'wind_speed' => 3.0,
        'wind_direction' => 180,
        'air_pressure' => 1012.50,
        'rainfall' => 0.1,
        'pm25' => 25.0,
        'pm10' => 35.0,
        'co2' => 450,
        'noise_level' => 55.0,
        'uv_index' => 7.5,
        'battery_level' => 88.0
    ];
    $resultST003 = $db->addMeasurement($measurementDataST003);

    $measurementDataST004 = [
        'station_id' => 'ST004',
        'temperature' => 30.0,
        'humidity' => 70.0,
        'light_intensity' => 15000,
        'wind_speed' => 1.8,
        'wind_direction' => 90,
        'air_pressure' => 1013.00,
        'rainfall' => 0.5,
        'pm25' => 20.0,
        'pm10' => 30.0,
        'co2' => 470,
        'noise_level' => 50.5,
        'uv_index' => 6.5,
        'battery_level' => 89.0
    ];
    $db->addMeasurement($measurementDataST004);
    
    // Thêm bản ghi đo cho Trạm ST005
    $measurementDataST005 = [
        'station_id' => 'ST005',
        'temperature' => 31.0,
        'humidity' => 72.0,
        'light_intensity' => 14000,
        'wind_speed' => 2.0,
        'wind_direction' => 120,
        'air_pressure' => 1012.80,
        'rainfall' => 0.2,
        'pm25' => 22.0,
        'pm10' => 33.0,
        'co2' => 480,
        'noise_level' => 52.0,
        'uv_index' => 7.0,
        'battery_level' => 90.0
    ];
    $db->addMeasurement($measurementDataST005);
    
} catch (Exception $e) {
    echo "Lỗi: " . $e->getMessage();
}
?>