-- Tạo cơ sở dữ liệu
-- CREATE DATABASE environmental_monitoringv4;

-- -- Sử dụng cơ sở dữ liệu vừa tạo
-- USE environmental_monitoring4;

-- Tạo bảng stations
CREATE TABLE stations (
    station_id VARCHAR(10) PRIMARY KEY,
    station_name VARCHAR(255) NOT NULL,
    address VARCHAR(255),
    phone VARCHAR(20),
    latitude DECIMAL(10, 7),
    longitude DECIMAL(10, 7),
    elevation DECIMAL(5, 2),
    installation_date DATE,
    status ENUM('active', 'inactive') DEFAULT 'active'
);

-- Tạo bảng measurements
CREATE TABLE measurements (
    measurement_id INT AUTO_INCREMENT PRIMARY KEY,
    station_id VARCHAR(10),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    temperature DECIMAL(5, 2),
    humidity DECIMAL(5, 2),
    light_intensity INT,
    wind_speed DECIMAL(5, 2),
    wind_direction DECIMAL(5, 2),
    air_pressure DECIMAL(6, 2),
    rainfall DECIMAL(5, 2),
    pm25 DECIMAL(5, 2),
    pm10 DECIMAL(5, 2),
    co2 DECIMAL(5, 2),
    noise_level DECIMAL(5, 2),
    uv_index DECIMAL(5, 2),
    battery_level DECIMAL(5, 2),
    FOREIGN KEY (station_id) REFERENCES stations(station_id)
);

-- Tạo bảng maintenance_logs
CREATE TABLE maintenance_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    station_id VARCHAR(10),
    maintenance_date DATE,
    maintenance_type VARCHAR(255),
    description TEXT,
    technician_name VARCHAR(255),
    next_maintenance_date DATE,
    FOREIGN KEY (station_id) REFERENCES stations(station_id)
);

-- Tạo bảng sensor_thresholds
CREATE TABLE sensor_thresholds (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    station_id VARCHAR(10),
    sensor_type VARCHAR(255),
    min_temperature DECIMAL(5, 2),
    max_temperature DECIMAL(5, 2),
    min_humidity DECIMAL(5, 2),
    max_humidity DECIMAL(5, 2),
    min_wind_speed DECIMAL(5, 2),
    max_wind_speed DECIMAL(5, 2),
    min_light INT,
    max_light INT,
    calibration_notes TEXT,
    valid_from DATETIME,
    valid_until DATETIME,
    technician_id VARCHAR(20),
    FOREIGN KEY (station_id) REFERENCES stations(station_id)
);

-- Tạo bảng alerts
CREATE TABLE alerts (
    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    station_id VARCHAR(10),
    alert_type VARCHAR(255),
    severity ENUM('low', 'medium', 'high') NOT NULL,
    message TEXT,
    resolved BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (station_id) REFERENCES stations(station_id)
);