<?php
require_once 'database.php';

// Khởi tạo kết nối cơ sở dữ liệu
// try {
//     $db = new EnvironmentalDatabase();
//     $station_id = 'ST001'; // ID trạm mặc định
//     $latestMeasurements = $db->getLatestMeasurements($station_id);
// } catch (Exception $e) {
//     $latestMeasurements = null;
//     $error = $e->getMessage();
// }
// Khởi tạo biến

////////////////////////////////////////////////
$station_id = 'ST001'; // ID trạm mặc định
$latestMeasurements = null;
$error = null;
$stations = []; // Danh sách các trạm

try {
    $db = new EnvironmentalDatabase();

    // Xử lý tìm kiếm
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Kiểm tra và làm sạch input
        $station_id = isset($_POST['station_id']) ? trim($_POST['station_id']) : $station_id;
        
        try {
            // Lấy dữ liệu đo mới nhất của trạm
            $latestMeasurements = $db->getLatestMeasurements($station_id);
            
            // Nếu không có dữ liệu, báo lỗi
            if (!$latestMeasurements) {
                $error = "Không tìm thấy dữ liệu cho trạm {$station_id}";
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }

    // Lấy danh sách các trạm (giả sử bạn có phương thức getAllStations())
    try {
        $stations = $db->getAllStations(); // Bạn cần thêm phương thức này vào class EnvironmentalDatabase
    } catch (Exception $e) {
        // Không hiển thị lỗi nếu không lấy được danh sách trạm
    }
} catch (Exception $e) {
    $error = "Lỗi kết nối cơ sở dữ liệu: " . $e->getMessage();
}
////////////////////////////////////////////////

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bảng Quan Trắc Môi Trường</title>
    
    <style>
        /* Định kiểu chữ cho tiêu đề BẢN ĐỒ STATIONS */
        .sales-boxes h1 {
            font-family: 'Arial', sans-serif;  /* Chọn font chữ phù hợp */
            font-size: 15px;                  /* Cỡ chữ */
            font-weight: bold;                /* Chữ đậm */
            color: #007BFF;                      /* Màu chữ */
            text-transform: uppercase;        /* Chữ in hoa */
            letter-spacing: 2px;              /* Khoảng cách giữa các ký tự */
            margin-bottom: 10px;              /* Khoảng cách dưới tiêu đề */
            padding-left: 5px;               /* Khoảng cách bên trái */
        }
    </style>


    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

   <!-- Thêm thư viện Leaflet -->
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
  <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>


</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-center mb-8 text-green-700">
            Hệ Thống Quan Trắc Môi Trường
        </h1>
        

        
<!-- Khung Tìm Kiếm Trạm -->
<div class="max-w-2xl mx-auto mb-8">
            <form method="POST" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                <div class="flex items-center space-x-4">
                    <!-- Input Tìm Kiếm -->
                    <div class="flex-grow">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="station_id">
                            Nhập Mã Trạm
                        </label>
                        <input 
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                            id="station_id" 
                            name="station_id" 
                            type="text" 
                            placeholder="Nhập mã trạm (VD: ST001)"
                            value="<?= htmlspecialchars($station_id) ?>"
                            list="stationList"
                        >
                        <!-- Datalist để gợi ý các trạm -->
                        <datalist id="stationList">
                            <?php foreach ($stations as $station): ?>
                                <option value="<?= htmlspecialchars($station['station_id']) ?>">
                                    <?= htmlspecialchars($station['station_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </datalist>
                    </div>
                    
                    <!-- Nút Tìm Kiếm -->
                    <div class="self-end">
                        <button 
                            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" 
                            type="submit"
                        >
                            Tìm Kiếm
                        </button>
                    </div>
                </div>
            </form>

            <!-- Hiển Thị Lỗi -->
            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                    <strong class="font-bold">Lỗi!</strong>
                    <span class="block sm:inline">
                        <?= htmlspecialchars($error) ?>
                    </span>
                </div>
            <?php endif; ?>
        </div>

        <!-- Kết thức thêm sreach -->










        <?php if ($latestMeasurements): ?>
            <div class="grid md:grid-cols-3 gap-6">
                <!-- Thông tin trạm -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-semibold mb-4 text-blue-600">
                        Thông Tin Trạm Quan Trắc
                    </h2>
                    <div class="space-y-2">
                        <!-- <p><strong>Mã Trạm:</strong> ST001</p>
                        <p><strong>Tên Trạm:</strong> Trạm Quan Trắc Môi Trường Hà Nội</p>
                        <p><strong>Địa Điểm:</strong> Đại học Khoa học Tự nhiên, Hà Nội</p>
                        <p><strong>Vị Trí:</strong> 
                            Lat: 21.0285, Long: 105.8542
                        </p>
                        </p> -->
                       
                        <?php
// Tìm thông tin trạm trong mảng stations
$station = null;
if (!empty($stations) && !empty($station_id)) {
    foreach ($stations as $s) {
        if ($s['station_id'] === $station_id) {
            $station = $s;
            break;
        }
    }
}
function displayLocation($lat, $long) {
    return "Lat: " . ($lat ?? 'Không rõ') . ", Long: " . ($long ?? 'Không rõ');
}
?>

<p><strong>Mã Trạm:</strong> <?= $station_id ?? 'Không rõ' ?></p>
<p><strong>Tên Trạm:</strong> <?= $station['station_name'] ?? 'Không rõ' ?></p>
<p><strong>Địa Điểm:</strong> <?= $station['address'] ?? 'Không rõ' ?></p>
<p><strong>Vị Trí:</strong> 
    <?= displayLocation(
        $station['latitude'] ?? null,
        $station['longitude'] ?? null
    ) ?>
</p>
                    </div>
                </div>

                <!-- Số Liệu Môi Trường -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-semibold mb-4 text-green-600">
                        Số Liệu Môi Trường
                    </h2>
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <strong>Nhiệt Độ:</strong> 
                            <?= $latestMeasurements['temperature'] ?>°C
                        </div>
                        <div>
                            <strong>Độ Ẩm:</strong> 
                            <?= $latestMeasurements['humidity'] ?>%
                        </div>
                        <div>
                            <strong>Áp Suất:</strong> 
                            <?= $latestMeasurements['air_pressure'] ?> hPa
                        </div>
                        <div>
                            <strong>Gió:</strong> 
                            <?= $latestMeasurements['wind_speed'] ?> m/s
                        </div>
                    </div>
                </div>

                <!-- Chất Lượng Không Khí -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-semibold mb-4 text-red-600">
                        Chất Lượng Không Khí
                    </h2>
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <strong>PM2.5:</strong> 
                            <?= $latestMeasurements['pm25'] ?> µg/m³
                        </div>
                        <div>
                            <strong>PM10:</strong> 
                            <?= $latestMeasurements['pm10'] ?> µg/m³
                        </div>
                        <div>
                            <strong>CO2:</strong> 
                            <?= $latestMeasurements['co2'] ?> ppm
                        </div>
                        <div>
                            <strong>Tiếng Ồn:</strong> 
                            <?= $latestMeasurements['noise_level'] ?> dB
                        </div>
                    </div>
                </div>
            </div>

            <!-- Biểu Đồ -->
            <div class="mt-8 grid md:grid-cols-2 gap-6">
                <!-- Biểu Đồ Nhiệt Độ -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-semibold mb-4 text-blue-600">
                        Biểu Đồ Nhiệt Độ
                    </h2>
                    <canvas id="temperatureChart"></canvas>
                </div>

                <!-- Biểu Đồ Chất Lượng Không Khí -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-semibold mb-4 text-green-600">
                        Chỉ Số Ô Nhiễm
                    </h2>
                    <canvas id="pollutionChart"></canvas>
                </div>
            </div>



            <script>
                // Biểu Đồ Nhiệt Độ
                var temperatureCtx = document.getElementById('temperatureChart').getContext('2d');
                new Chart(temperatureCtx, {
                    type: 'line',
                    data: {
                        labels: ['Nhiệt Độ', 'Độ Ẩm', 'Áp Suất'],
                        datasets: [{
                            label: 'Giá Trị',
                            data: [
                                <?= $latestMeasurements['temperature'] ?>, 
                                <?= $latestMeasurements['humidity'] ?>, 
                                <?= $latestMeasurements['air_pressure'] ?>
                            ],
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1
                        }]
                    }
                });

                // Biểu Đồ Chất Lượng Không Khí
                var pollutionCtx = document.getElementById('pollutionChart').getContext('2d');
                new Chart(pollutionCtx, {
                    type: 'bar',
                    data: {
                        labels: ['PM2.5', 'PM10', 'CO2', 'Tiếng Ồn'],
                        datasets: [{
                            label: 'Nồng Độ',
                            data: [
                                <?= $latestMeasurements['pm25'] ?>, 
                                <?= $latestMeasurements['pm10'] ?>, 
                                <?= $latestMeasurements['co2'] ?>, 
                                <?= $latestMeasurements['noise_level'] ?>
                            ],
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.6)',
                                'rgba(54, 162, 235, 0.6)',
                                'rgba(255, 206, 86, 0.6)',
                                'rgba(75, 192, 192, 0.6)'
                            ]
                        }]
                    }
                });


            
            </script>
            <div class="sales-boxes">
                <h1>BẢN ĐỒ STATIONS
                </h1>
  <div class="recent-sales box" style="width:100%;">
    <div align="center">
      <!-- Bản đồ sẽ được hiển thị ở đây -->
      <div id="map" style="width: 100%; height: 400px;"></div>
    </div>
  </div>
</div>
<script>
  // Khởi tạo bản đồ
  var map = L.map('map').setView([21.0285, 105.8542], 6); // Tọa độ trung tâm và zoom

  // Thêm layer bản đồ từ OpenStreetMap
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);

  // Dữ liệu các trạm quan trắc
  var stations = [
    {
      station_id: 'ST001',
      station_name: 'Trạm Quan Trắc Môi Trường Hà Nội',
      latitude: 21.0285,
      longitude: 105.8542
    },
    {
      station_id: 'ST002',
      station_name: 'Trạm Quan Trắc Môi Trường Hồ Chí Minh',
      latitude: 10.7731,
      longitude: 106.6594
    },
    {
      station_id: 'ST003',
      station_name: 'Trạm Quan Trắc Môi Trường Đà Nẵng',
      latitude: 16.0544,
      longitude: 108.2022
    },
    {
      station_id: 'ST004',
      station_name: 'Trạm Quan Trắc Môi Trường Cần Thơ',
      latitude: 10.0301,
      longitude: 105.7845
    },
    {
      station_id: 'ST005',
      station_name: 'Trạm Quan Trắc Môi Trường Huế',
      latitude: 16.4625,
      longitude: 107.5960
    }
  ];

  // Thêm các điểm đánh dấu cho các trạm
  stations.forEach(function(station) {
    L.marker([station.latitude, station.longitude])
      .addTo(map)
      .bindPopup("<b>" + station.station_name + "</b><br>Station ID: " + station.station_id);
  });
</script>

            
        <?php else: ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">Lỗi!</strong>
                <span class="block sm:inline">
                    Không thể tải dữ liệu môi trường. 
                    <?= $error ?? 'Vui lòng kiểm tra kết nối cơ sở dữ liệu.' ?>
                </span>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>